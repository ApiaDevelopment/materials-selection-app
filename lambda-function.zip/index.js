const { DynamoDBClient } = require('@aws-sdk/client-dynamodb');
const { DynamoDBDocumentClient, PutCommand, GetCommand, UpdateCommand, DeleteCommand, ScanCommand, QueryCommand } = require('@aws-sdk/lib-dynamodb');
const { randomUUID } = require('crypto');

const client = new DynamoDBClient({ region: 'us-east-1' });
const ddb = DynamoDBDocumentClient.from(client);

const PROJECTS_TABLE = 'MaterialsSelection-Projects';
const CATEGORIES_TABLE = 'MaterialsSelection-Categories';
const LINEITEMS_TABLE = 'MaterialsSelection-LineItems';

const headers = {
    'Content-Type': 'application/json',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type,Authorization',
    'Access-Control-Allow-Methods': 'GET,POST,PUT,DELETE,OPTIONS'
};

exports.handler = async (event) => {
    console.log('Event:', JSON.stringify(event, null, 2));
    
    if (event.requestContext.http.method === 'OPTIONS') {
        return { statusCode: 200, headers, body: '' };
    }

    const path = event.requestContext.http.path;
    const method = event.requestContext.http.method;
    
    try {
        // Projects routes
        if (path === '/projects' && method === 'GET') {
            return await getAllProjects();
        }
        if (path.match(/^\/projects\/[^\/]+$/) && method === 'GET') {
            const id = path.split('/')[2];
            return await getProject(id);
        }
        if (path === '/projects' && method === 'POST') {
            return await createProject(JSON.parse(event.body));
        }
        if (path.match(/^\/projects\/[^\/]+$/) && method === 'PUT') {
            const id = path.split('/')[2];
            return await updateProject(id, JSON.parse(event.body));
        }
        if (path.match(/^\/projects\/[^\/]+$/) && method === 'DELETE') {
            const id = path.split('/')[2];
            return await deleteProject(id);
        }

        // Categories routes
        if (path.match(/^\/projects\/[^\/]+\/categories$/) && method === 'GET') {
            const projectId = path.split('/')[2];
            return await getCategoriesByProject(projectId);
        }
        if (path.match(/^\/categories\/[^\/]+$/) && method === 'GET') {
            const id = path.split('/')[2];
            return await getCategory(id);
        }
        if (path === '/categories' && method === 'POST') {
            return await createCategory(JSON.parse(event.body));
        }
        if (path.match(/^\/categories\/[^\/]+$/) && method === 'PUT') {
            const id = path.split('/')[2];
            return await updateCategory(id, JSON.parse(event.body));
        }
        if (path.match(/^\/categories\/[^\/]+$/) && method === 'DELETE') {
            const id = path.split('/')[2];
            return await deleteCategory(id);
        }

        // LineItems routes
        if (path.match(/^\/categories\/[^\/]+\/lineitems$/) && method === 'GET') {
            const categoryId = path.split('/')[2];
            return await getLineItemsByCategory(categoryId);
        }
        if (path.match(/^\/projects\/[^\/]+\/lineitems$/) && method === 'GET') {
            const projectId = path.split('/')[2];
            return await getLineItemsByProject(projectId);
        }
        if (path.match(/^\/lineitems\/[^\/]+$/) && method === 'GET') {
            const id = path.split('/')[2];
            return await getLineItem(id);
        }
        if (path === '/lineitems' && method === 'POST') {
            return await createLineItem(JSON.parse(event.body));
        }
        if (path.match(/^\/lineitems\/[^\/]+$/) && method === 'PUT') {
            const id = path.split('/')[2];
            return await updateLineItem(id, JSON.parse(event.body));
        }
        if (path.match(/^\/lineitems\/[^\/]+$/) && method === 'DELETE') {
            const id = path.split('/')[2];
            return await deleteLineItem(id);
        }

        return { statusCode: 404, headers, body: JSON.stringify({ message: 'Not found' }) };
    } catch (error) {
        console.error('Error:', error);
        return { 
            statusCode: 500, 
            headers, 
            body: JSON.stringify({ message: error.message }) 
        };
    }
};

// Project functions
async function getAllProjects() {
    const result = await ddb.send(new ScanCommand({ TableName: PROJECTS_TABLE }));
    return { statusCode: 200, headers, body: JSON.stringify(result.Items || []) };
}

async function getProject(id) {
    const result = await ddb.send(new GetCommand({ TableName: PROJECTS_TABLE, Key: { id } }));
    if (!result.Item) {
        return { statusCode: 404, headers, body: JSON.stringify({ message: 'Project not found' }) };
    }
    return { statusCode: 200, headers, body: JSON.stringify(result.Item) };
}

async function createProject(data) {
    const project = {
        id: randomUUID(),
        name: data.name,
        description: data.description,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    await ddb.send(new PutCommand({ TableName: PROJECTS_TABLE, Item: project }));
    return { statusCode: 201, headers, body: JSON.stringify(project) };
}

async function updateProject(id, data) {
    const project = {
        ...data,
        id,
        updatedAt: new Date().toISOString()
    };
    await ddb.send(new PutCommand({ TableName: PROJECTS_TABLE, Item: project }));
    return { statusCode: 200, headers, body: JSON.stringify(project) };
}

async function deleteProject(id) {
    await ddb.send(new DeleteCommand({ TableName: PROJECTS_TABLE, Key: { id } }));
    return { statusCode: 204, headers, body: '' };
}

// Category functions
async function getCategoriesByProject(projectId) {
    const result = await ddb.send(new QueryCommand({
        TableName: CATEGORIES_TABLE,
        IndexName: 'ProjectIdIndex',
        KeyConditionExpression: 'projectId = :projectId',
        ExpressionAttributeValues: { ':projectId': projectId }
    }));
    return { statusCode: 200, headers, body: JSON.stringify(result.Items || []) };
}

async function getCategory(id) {
    const result = await ddb.send(new GetCommand({ TableName: CATEGORIES_TABLE, Key: { id } }));
    if (!result.Item) {
        return { statusCode: 404, headers, body: JSON.stringify({ message: 'Category not found' }) };
    }
    return { statusCode: 200, headers, body: JSON.stringify(result.Item) };
}

async function createCategory(data) {
    const category = {
        id: randomUUID(),
        projectId: data.projectId,
        name: data.name,
        description: data.description,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    await ddb.send(new PutCommand({ TableName: CATEGORIES_TABLE, Item: category }));
    return { statusCode: 201, headers, body: JSON.stringify(category) };
}

async function updateCategory(id, data) {
    const category = {
        ...data,
        id,
        updatedAt: new Date().toISOString()
    };
    await ddb.send(new PutCommand({ TableName: CATEGORIES_TABLE, Item: category }));
    return { statusCode: 200, headers, body: JSON.stringify(category) };
}

async function deleteCategory(id) {
    await ddb.send(new DeleteCommand({ TableName: CATEGORIES_TABLE, Key: { id } }));
    return { statusCode: 204, headers, body: '' };
}

// LineItem functions
async function getLineItemsByCategory(categoryId) {
    const result = await ddb.send(new QueryCommand({
        TableName: LINEITEMS_TABLE,
        IndexName: 'CategoryIdIndex',
        KeyConditionExpression: 'categoryId = :categoryId',
        ExpressionAttributeValues: { ':categoryId': categoryId }
    }));
    return { statusCode: 200, headers, body: JSON.stringify(result.Items || []) };
}

async function getLineItemsByProject(projectId) {
    const result = await ddb.send(new QueryCommand({
        TableName: LINEITEMS_TABLE,
        IndexName: 'ProjectIdIndex',
        KeyConditionExpression: 'projectId = :projectId',
        ExpressionAttributeValues: { ':projectId': projectId }
    }));
    return { statusCode: 200, headers, body: JSON.stringify(result.Items || []) };
}

async function getLineItem(id) {
    const result = await ddb.send(new GetCommand({ TableName: LINEITEMS_TABLE, Key: { id } }));
    if (!result.Item) {
        return { statusCode: 404, headers, body: JSON.stringify({ message: 'LineItem not found' }) };
    }
    return { statusCode: 200, headers, body: JSON.stringify(result.Item) };
}

async function createLineItem(data) {
    const totalCost = data.quantity * data.unitCost;
    const lineItem = {
        id: randomUUID(),
        categoryId: data.categoryId,
        projectId: data.projectId,
        name: data.name,
        material: data.material,
        quantity: data.quantity,
        unit: data.unit,
        unitCost: data.unitCost,
        totalCost: totalCost,
        notes: data.notes || '',
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString()
    };
    await ddb.send(new PutCommand({ TableName: LINEITEMS_TABLE, Item: lineItem }));
    return { statusCode: 201, headers, body: JSON.stringify(lineItem) };
}

async function updateLineItem(id, data) {
    const totalCost = data.quantity * data.unitCost;
    const lineItem = {
        ...data,
        id,
        totalCost: totalCost,
        updatedAt: new Date().toISOString()
    };
    await ddb.send(new PutCommand({ TableName: LINEITEMS_TABLE, Item: lineItem }));
    return { statusCode: 200, headers, body: JSON.stringify(lineItem) };
}

async function deleteLineItem(id) {
    await ddb.send(new DeleteCommand({ TableName: LINEITEMS_TABLE, Key: { id } }));
    return { statusCode: 204, headers, body: '' };
}
